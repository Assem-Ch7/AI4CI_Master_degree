# Exercise 1


## Start the lab
To start the lab run `make start`
Access the server: `ssh student@0.0.0.0 -p2222`. The password is password.

## Stop the lab
To stop the lab run `make stop` 