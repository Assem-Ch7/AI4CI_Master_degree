import ssl
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BALANCES = {
    "alice": 1000,
    "bob": 150
}

def get_amount_for_user(user:str) -> int:
    return BALANCES[user]

class RequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        parsed_url = urlparse(self.path)
        path = parsed_url.path
        query_params = parse_qs(parsed_url.query) 
        if path == "/payment":
            amount = query_params.get('amount', 0)[0]
            try:
                amount = int(amount)
                
                user,is_authorized = "",False # TODO: Get user from certificate and check if user is authorized. Certificate for the user needs to be valid
                
                if not is_authorized:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write("You are not authorized".encode())
                else:
                    account_amount = get_amount_for_user(user)
                    if amount > account_amount:
                        self.send_response(400)
                        self.end_headers()
                        self.wfile.write("You do not have enough funds in your account".encode())
                    else:
                        pass # TODO: subtract the the amount from the user balance 

            except Exception as e:
                print(e)
                self.send_response(400)
                self.end_headers()
                self.wfile.write("Amount is not correct".encode())
                
            


def run_server():
    # TODO: implement mTLS logic and extract user information using the CN in the client certificate
    server_address = ('localhost', 8080)
    httpd = HTTPServer(server_address, RequestHandler)
    
    print("Server running on http://localhost:8080")
    httpd.serve_forever()


if __name__ == "__main__":
    run_server()
